﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql;
using MySql.Data.MySqlClient;
using System.IO;

namespace pekseg_ujtermek
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            /*
                INSERT INTO `termek` (`termek_id`, `neve`, `gluten_M`, `laktoz_M`, `cukor_M`, `ar`, `tomeg`)
                VALUES ('cs-001', 'sonkás kifli', 0, 0, 0, 250, 50),

                Ez csak egy minta a sor hozzáadásra.
             */

            string hozzaadas = "INSERT INTO `termek` (`termek_id`, `neve`, `gluten_M`, `laktoz_M`, `cukor_M`, `ar`, `tomeg`) VALUES('";    // az SQL lekérdezés eleje
                       
            int termek_id = 0;

            MySqlConnection conn = new MySqlConnection("server=localhost;database=pekseg;uid=root;pwd=;SslMode=none");  //Az adatbázis kapcsolat beállítása

            conn.Open();    //kapcsolódás az adatbázishoz

            string id_lekerdezes = "SELECT `termek_id` FROM `termek` ORDER BY `termek_id` DESC LIMIT 1;";       //a legnagyobb azonosítójú rendelés
            MySqlCommand cmd_id_lekerdezes = new MySqlCommand(id_lekerdezes, conn);
            MySqlDataReader rdr_id_lekerdezes = cmd_id_lekerdezes.ExecuteReader();

            while (rdr_id_lekerdezes.Read())
            {
                termek_id = Convert.ToInt32(rdr_id_lekerdezes[0]) + 1;   //az utolsó legnagyobb rendelés azonosító lekérdezése és plusz egy hozzáadása
            }
            rdr_id_lekerdezes.Close();      // lekérdezés lezárása (eredményének eldobása)
            conn.Close(); // kapcsolat lezárása

            textBox1.Text = termek_id.ToString();       // új id kiírása a szövegdobozba
            
            string neve = textBox2.Text;

            bool gluten_M = checkBox1.Checked;

            int gluten_M_I = 0;

            if (gluten_M == true)
            {
                gluten_M_I = 1;
            }

            bool laktoz_M = checkBox2.Checked;

            int laktoz_M_I = 0;

            if (laktoz_M == true)
            {
                laktoz_M_I = 1;
            }

            bool cukor_M = checkBox3.Checked;

            int cukor_M_I = 0;

            if (cukor_M == true)
            {
                cukor_M_I = 1;
            }

            string ar = textBox3.Text;

            string tomeg = textBox4.Text;

            hozzaadas += termek_id + "', '" + neve + "', " + gluten_M_I + ", " + laktoz_M_I + ", " + cukor_M_I + ", " + ar + ", " + tomeg + ")";  // az sql lekérdezés befejezése

            richTextBox1.Text = 
                "A következő termék lett felvéve:\n" +
                "Azonosítója: " + termek_id + "\n" +
                "Neve: " + neve + "\n" +
                "Glutén mentes? " + gluten_M_I + "\n" +
                "Laktóz mentes? " + laktoz_M_I + "\n" +
                "Cukor mentes? " + cukor_M_I + "\n" +
                "Ára: " + ar + " Ft\n" +
                "Tömege: " + termek_id + " gramm\n" +
                "Az elküldött SQL parancs: " + hozzaadas;

            //MySqlConnection conn = new MySqlConnection("server=localhost;database=pekseg;uid=root;pwd=;SslMode=none");  //Az adatbázis kapcsolat beállítása

            conn.Open();    //kapcsolódás az adatbázishoz

            string SQL_hozzaadas = hozzaadas;       // a legenerált string "beolvasása" a lekérdezésnek
            MySqlCommand cmd = new MySqlCommand(SQL_hozzaadas, conn);
            MySqlDataReader rdr = cmd.ExecuteReader();

            while (rdr.Read()) // üres ez a ciklus, mert nem kell hogy eredményt gyűjtsön, vagy írjon valahová. Csak lefut a sor hozzáadása.
            {
            }
            rdr.Close(); // lekérdezés lezárása (eredményének eldobása)

        }

        private void button2_Click(object sender, EventArgs e)
        {
            // a HTML "fejrészének" megírása

            string HTML_kod_e =
                "<!DOCTYPE html>" +
                "<html lang='hu'>" +
                "<head><meta charset='utf-8'><link href='https://fonts.googleapis.com/css2?family=Righteous&display=swap' rel='stylesheet'><link rel='stylesheet' href='pekseg.css'></head>" +
                "<body style='background:rgba(240, 232, 221, 0.7)'>" +
                "<H1>Termékek</H1>" +
                "<table>" +
                "<tr><th>Termék neve</th><th>Ára (Ft)</th><th>Tömege (g)</th><th>Glutén mentes</th><th>Laktóz mentes</th><th>Cukor mentes</th></tr>";

            // a HTML "lábrészének" megírása

            string HTML_kod_v =
                "</table>" +
                "</body>" +
                "</html>";

            MySqlConnection conn = new MySqlConnection("server=localhost;database=pekseg;uid=root;pwd=;SslMode=none");  //Az adatbázis kapcsolat beállítása

            conn.Open();    //kapcsolódás az adatbázishoz

            string termek_lekerdezes = "SELECT * FROM `termek`";   // a lekérdezés a termékek legenerálásához (gyakorlatilag minden termék lekérdezése)
            MySqlCommand cmd = new MySqlCommand(termek_lekerdezes, conn);
            MySqlDataReader rdr = cmd.ExecuteReader();

            StreamWriter Console2 = new StreamWriter("termek.html");     // html fájl írásának megkezdése

            Console2.WriteLine(HTML_kod_e);     // html fájl elejének beleírása a fáljba

            while (rdr.Read())      
            {
                // lekérdezés soronként, azon belül oszloponként, és összefűzése egy HTML beágyazott stringgé
                string szoveg = (
                    "<tr><td>" +
                    rdr[1] +
                    "</td><td>" +
                    rdr[5] +
                    "</td><td>" +
                    rdr[6] +
                    "</td><td>" +
                    ( Convert.ToInt32(rdr[2]) == 1 ? "Igen" : "Nem") +      // ez egy rövidített IF fügvény, arra hogy az adatbázisben szereplő 0-ból és 1-ből, a honlapon szereplő "igen" és "nem" legyen
                    "</td><td>" +
                    ( Convert.ToInt32(rdr[3]) == 1 ? "Igen" : "Nem") +
                    "</td><td>" +
                    ( Convert.ToInt32(rdr[4]) == 1 ? "Igen" : "Nem") + 
                    "</td></tr>");
                Console2.WriteLine(szoveg);
            }

            Console2.WriteLine(HTML_kod_v);     // html fájl végének beleírása a fáljba

            Console2.Close();   //console2 lezárása
            rdr.Close(); // lekérdezés lezárása (eredményének eldobása)
            conn.Close(); // kapcsolat lezárása

            richTextBox2.Text += "Az új táblázat kész a honlaphoz.\n";
        }
    }
}
