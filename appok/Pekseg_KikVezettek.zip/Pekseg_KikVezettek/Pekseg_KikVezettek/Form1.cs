﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql;                                        //hozzá kell adni
using MySql.Data.MySqlClient;                       //ezt is
using System.IO;

namespace Pekseg_KikVezettek
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            MySqlConnection conn = new MySqlConnection("server=localhost;database=pekseg;uid=root;pwd=;SslMode=none");  //Az adatbázis kapcsolat beállítása

            conn.Open();    //kapcsolódás az adatbázishoz

            string auto_lekerdezes = "SELECT `rendszam` FROM `jarmuvek`; ";       //rendszámok sql lekérdezése
            MySqlCommand cmd_auto = new MySqlCommand(auto_lekerdezes, conn);
            MySqlDataReader rdr_auto = cmd_auto.ExecuteReader();

            while (rdr_auto.Read())
            {
                string auto = rdr_auto[0].ToString();   //sql lekérdezés lefutása soronként
                comboBox1.Items.Add(auto);              //kapott eredmény hozzáadása a legördülő listához
            }
            rdr_auto.Close(); // lekérdezés lezárása (eredményének eldobása)

            conn.Close(); // kapcsolat lezárása

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string kiv_rendszam = comboBox1.SelectedItem.ToString();

            string kivezette_lekerdezes =
                "SELECT `kereszt_nev`, `vezetek_nev`, `szallitas_datum` " +
                "FROM `szemelyzet` INNER JOIN `rendeles` ON `rendeles`.`dolg_id` = `szemelyzet`.`dolg_id` " +
                "WHERE `rendszam` LIKE '" + kiv_rendszam + "';";       //a lekérdezés, ami megkeresi hogy ki is mikor vitt el, egy kiválasztott rendszámú autót


            MySqlConnection conn = new MySqlConnection("server=localhost;database=pekseg;uid=root;pwd=;SslMode=none");  //Az adatbázis kapcsolat beállítása

            conn.Open();    //kapcsolódás az adatbázishoz

            MySqlCommand cmd = new MySqlCommand(kivezette_lekerdezes, conn);
            MySqlDataReader rdr = cmd.ExecuteReader();

            string kivezette = "";

            while (rdr.Read())
            {
                string vezeteknev = rdr[0].ToString();
                string keresztnev = rdr[1].ToString();
                DateTime dateTime = Convert.ToDateTime(rdr[2]);

                kivezette += "A járművet " + vezeteknev + " " + keresztnev + " " + dateTime.ToString("yyyy. MM. dd.") + " napján vezette.\n";
            }

            rdr.Close(); // lekérdezés lezárása (eredményének eldobása)

            conn.Close(); // kapcsolat lezárása

            richTextBox1.Text = kivezette;

        }
    }
}
